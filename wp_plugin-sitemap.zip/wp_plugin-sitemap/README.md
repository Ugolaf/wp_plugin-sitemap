# WP Plugin sitemap

[![Build Status](https://app.travis-ci.com/Ugolaf/wp_plugin-sitemap.svg?branch=master)](https://app.travis-ci.com/Ugolaf/wp_plugin-sitemap)

This plugin allows a wordpress administrator to manually trigger a crawl of their website pages and view the results on a back-end admin page. The crawler extracts all of the internal hyperlinks from the website's home page and stores the results temporarily in the database. It then displays the results on the admin page and creates a sitemap.html file that shows the results as a sitemap list structure.

[![wp-plugin-sitemap.png](https://i.postimg.cc/L6G5dSgX/wp-plugin-sitemap.png)](https://postimg.cc/CzHSDWNT)


### Features
- Back-end admin page for manual triggering of website crawl
- Crawls website every hour
- Extracts internal hyperlinks from website's home page
- Stores results temporarily in the database
- Deletes the results from the last crawl and sitemap.html file
- Displays results on the admin page
- Displays error notice if an error occurs
- Creates a sitemap.html file that shows the results as a sitemap list structure
- Front-end access for visitors to view the sitemap.html page

### Requirements
Wordpress 5.0 or higher
MySQL or MariaDB

### Installation
Clone or download the repository and copy the files to your WordPress plugin directory or your PHP web app root directory.
Activate the plugin in WordPress or include the required files in your PHP web app.
Configure the database connection in the config.php file.
Access the back-end admin page and trigger a crawl to start generating the sitemap.

### Usage
Log in to the back-end admin page.
Trigger a crawl to start generating the sitemap.
View the results on the admin page.
Access the sitemap.html page from the front-end.

### Credits
This app was developed by Ugo LAFAILLE. Based on [wp-media/package-template](https://github.com/wp-media/package-template).
